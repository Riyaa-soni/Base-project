import {config} from "dotenv";
config();

import { startServer } from "./app/app";
startServer();


import { adminList } from "./app/utility/populate-admin";
import authServices from "./app/feature-modules/auth/auth.services";

// const populateDb = () => {

//     // roleServices.create({ _id : ROLE.ADMIN, name : "admin"})
//     // roleServices.create({ _id : ROLE.TRAINER, name : "trainer"})

//     for(let admin of adminList){
//      authServices.register(admin)
//     }
  
// }

// populateDb();