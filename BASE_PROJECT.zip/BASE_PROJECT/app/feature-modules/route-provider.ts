import userRouter from "./user/user.routes"
import roleRouter from "./roles/role.routes"
import authRouter from "./auth/auth.routes"


export default { userRouter, roleRouter,authRouter}